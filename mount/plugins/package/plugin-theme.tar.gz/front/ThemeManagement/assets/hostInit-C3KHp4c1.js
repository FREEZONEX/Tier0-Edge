const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/remoteEntry-BscycsRP.js","assets/supos_mf_2_ce_mf_1_ThemeManagement__mf_v__runtimeInit__mf_v__-ChL15C7k.js","assets/virtualExposes-H450rS3X.js","assets/preload-helper-Cgrh1dHK.js"])))=>i.map(i=>d[i]);
import { _ as __vitePreload } from "./preload-helper-Cgrh1dHK.js";
const remoteEntryPromise = __vitePreload(() => import("./remoteEntry-BscycsRP.js"), true ? __vite__mapDeps([0,1,2,3]) : void 0);
Promise.resolve(remoteEntryPromise).then((remoteEntry) => {
  return Promise.resolve(remoteEntry.__tla).then(remoteEntry.init).catch(remoteEntry.init);
});
