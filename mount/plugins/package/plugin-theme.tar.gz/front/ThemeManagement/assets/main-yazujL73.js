import "./hostInit-C3KHp4c1.js";
import { s as supos_mf_2_ce_mf_1_ThemeManagement__mf_v__runtimeInit__mf_v__, a as index_cjs } from "./supos_mf_2_ce_mf_1_ThemeManagement__mf_v__runtimeInit__mf_v__-ChL15C7k.js";
import { j as jsxRuntimeExports, C as CodeManagement } from "./App-NN_ccB2q.js";
import { s as supos_mf_2_ce_mf_1_ThemeManagement__loadShare__react__loadShare__ } from "./supos_mf_2_ce_mf_1_ThemeManagement__loadShare__react__loadShare__-DEEdZRUw.js";
import { s as supos_mf_2_ce_mf_1_ThemeManagement__loadShare__react_mf_2_dom__loadShare__ } from "./supos_mf_2_ce_mf_1_ThemeManagement__loadShare__react_mf_2_dom__loadShare__-DEIMXv8A.js";
import "./preload-helper-Cgrh1dHK.js";
import "./_commonjsHelpers-CUmg6egw.js";
var createRoot;
var m = supos_mf_2_ce_mf_1_ThemeManagement__loadShare__react_mf_2_dom__loadShare__;
{
  createRoot = m.createRoot;
  m.hydrateRoot;
}
const { loadShare } = index_cjs;
const { initPromise } = supos_mf_2_ce_mf_1_ThemeManagement__mf_v__runtimeInit__mf_v__;
const res = initPromise.then((_) => loadShare("react-router-dom", {
  customShareInfo: { shareConfig: {
    singleton: true,
    strictVersion: false,
    requiredVersion: "^6.27.0"
  } }
}));
const exportModule = await res.then((factory) => factory());
var supos_mf_2_ce_mf_1_ThemeManagement__loadShare__react_mf_2_router_mf_2_dom__loadShare__ = exportModule;
createRoot(document.getElementById("root")).render(
  /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_ThemeManagement__loadShare__react__loadShare__.StrictMode, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_ThemeManagement__loadShare__react_mf_2_router_mf_2_dom__loadShare__.BrowserRouter, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(CodeManagement, {}) }) })
);
