import { s as supos_mf_2_ce_mf_1_ThemeManagement__loadShare__react__loadShare__ } from "./supos_mf_2_ce_mf_1_ThemeManagement__loadShare__react__loadShare__-DEEdZRUw.js";
import { s as supos_mf_2_ce_mf_1_ThemeManagement__mf_v__runtimeInit__mf_v__, a as index_cjs } from "./supos_mf_2_ce_mf_1_ThemeManagement__mf_v__runtimeInit__mf_v__-ChL15C7k.js";
var jsxRuntime = { exports: {} };
var reactJsxRuntime_production_min = {};
/**
 * @license React
 * react-jsx-runtime.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
var f = supos_mf_2_ce_mf_1_ThemeManagement__loadShare__react__loadShare__, k = Symbol.for("react.element"), l = Symbol.for("react.fragment"), m = Object.prototype.hasOwnProperty, n = f.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner, p = { key: true, ref: true, __self: true, __source: true };
function q(c, a, g) {
  var b, d = {}, e = null, h = null;
  void 0 !== g && (e = "" + g);
  void 0 !== a.key && (e = "" + a.key);
  void 0 !== a.ref && (h = a.ref);
  for (b in a) m.call(a, b) && !p.hasOwnProperty(b) && (d[b] = a[b]);
  if (c && c.defaultProps) for (b in a = c.defaultProps, a) void 0 === d[b] && (d[b] = a[b]);
  return { $$typeof: k, type: c, key: e, ref: h, props: d, _owner: n.current };
}
reactJsxRuntime_production_min.Fragment = l;
reactJsxRuntime_production_min.jsx = q;
reactJsxRuntime_production_min.jsxs = q;
{
  jsxRuntime.exports = reactJsxRuntime_production_min;
}
var jsxRuntimeExports = jsxRuntime.exports;
const { loadShare: loadShare$1 } = index_cjs;
const { initPromise: initPromise$6 } = supos_mf_2_ce_mf_1_ThemeManagement__mf_v__runtimeInit__mf_v__;
const res$6 = initPromise$6.then((_) => loadShare$1("@carbon/icons-react", {
  customShareInfo: { shareConfig: {
    singleton: true,
    strictVersion: false,
    requiredVersion: "^11.60.0"
  } }
}));
const exportModule$6 = await res$6.then((factory) => factory());
var supos_mf_2_ce_mf_1_ThemeManagement__loadShare___mf_0_carbon_mf_1_icons_mf_2_react__loadShare__ = exportModule$6;
const { loadRemote: loadRemote$4 } = index_cjs;
const { initPromise: initPromise$5 } = supos_mf_2_ce_mf_1_ThemeManagement__mf_v__runtimeInit__mf_v__;
const res$5 = initPromise$5.then((_) => loadRemote$4("@supos_host/components"));
const exportModule$5 = await initPromise$5.then((_) => res$5);
var supos_mf_2_ce_mf_1_ThemeManagement__loadRemote___mf_0_supos_host_mf_1_components__loadRemote__ = exportModule$5;
const { loadRemote: loadRemote$3 } = index_cjs;
const { initPromise: initPromise$4 } = supos_mf_2_ce_mf_1_ThemeManagement__mf_v__runtimeInit__mf_v__;
const res$4 = initPromise$4.then((_) => loadRemote$3("@supos_host/hooks"));
const exportModule$4 = await initPromise$4.then((_) => res$4);
var supos_mf_2_ce_mf_1_ThemeManagement__loadRemote___mf_0_supos_host_mf_1_hooks__loadRemote__ = exportModule$4;
const { loadShare } = index_cjs;
const { initPromise: initPromise$3 } = supos_mf_2_ce_mf_1_ThemeManagement__mf_v__runtimeInit__mf_v__;
const res$3 = initPromise$3.then((_) => loadShare("antd", {
  customShareInfo: { shareConfig: {
    singleton: true,
    strictVersion: false,
    requiredVersion: "5.27.1"
  } }
}));
const exportModule$3 = await res$3.then((factory) => factory());
var supos_mf_2_ce_mf_1_ThemeManagement__loadShare__antd__loadShare__ = exportModule$3;
const { loadRemote: loadRemote$2 } = index_cjs;
const { initPromise: initPromise$2 } = supos_mf_2_ce_mf_1_ThemeManagement__mf_v__runtimeInit__mf_v__;
const res$2 = initPromise$2.then((_) => loadRemote$2("@supos_host/baseStore"));
const exportModule$2 = await initPromise$2.then((_) => res$2);
var supos_mf_2_ce_mf_1_ThemeManagement__loadRemote___mf_0_supos_host_mf_1_baseStore__loadRemote__ = exportModule$2;
const { loadRemote: loadRemote$1 } = index_cjs;
const { initPromise: initPromise$1 } = supos_mf_2_ce_mf_1_ThemeManagement__mf_v__runtimeInit__mf_v__;
const res$1 = initPromise$1.then((_) => loadRemote$1("@supos_host/i18nStore"));
const exportModule$1 = await initPromise$1.then((_) => res$1);
var supos_mf_2_ce_mf_1_ThemeManagement__loadRemote___mf_0_supos_host_mf_1_i18nStore__loadRemote__ = exportModule$1;
const I18N_NAME = "theme-manager";
const Module$2 = ({ fileList: _fileList, fileChange, maxCount = 1, ...restProps }) => {
  const { message } = supos_mf_2_ce_mf_1_ThemeManagement__loadShare__antd__loadShare__.App.useApp();
  const formatMessage = supos_mf_2_ce_mf_1_ThemeManagement__loadRemote___mf_0_supos_host_mf_1_hooks__loadRemote__.useTranslate(I18N_NAME);
  const [fileList, setFileList] = supos_mf_2_ce_mf_1_ThemeManagement__loadShare__react__loadShare__.useState(_fileList);
  const beforeUpload = (file) => {
    const fileType = file.name.split(".").pop();
    if (["jpg", "jpeg", "png", "svg"].includes(fileType.toLowerCase())) {
      const previewUrl = URL.createObjectURL(file);
      const newFile = {
        ...file,
        file,
        url: previewUrl,
        thumbUrl: previewUrl,
        status: "done"
      };
      setFileList([newFile]);
      fileChange == null ? void 0 : fileChange([newFile]);
    } else {
      message.warning(formatMessage("imgFormatSupport", { format: "jpg、jpeg、png、svg" }));
      return supos_mf_2_ce_mf_1_ThemeManagement__loadShare__antd__loadShare__.Upload.LIST_IGNORE;
    }
    return false;
  };
  const onRemove = () => {
    setFileList([]);
    fileChange == null ? void 0 : fileChange();
  };
  supos_mf_2_ce_mf_1_ThemeManagement__loadShare__react__loadShare__.useEffect(() => {
    setFileList(_fileList);
  }, [_fileList]);
  return /* @__PURE__ */ jsxRuntimeExports.jsx(
    supos_mf_2_ce_mf_1_ThemeManagement__loadShare__antd__loadShare__.Upload,
    {
      action: "",
      listType: "picture-card",
      maxCount,
      ...restProps,
      fileList,
      accept: ".jpg,.jpeg,.png,.svg",
      beforeUpload,
      onRemove,
      children: fileList && (fileList == null ? void 0 : fileList.length) >= maxCount ? null : /* @__PURE__ */ jsxRuntimeExports.jsx("button", { style: { color: "inherit", cursor: "inherit", border: 0, background: "none" }, type: "button", children: /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_ThemeManagement__loadShare___mf_0_carbon_mf_1_icons_mf_2_react__loadShare__.AddLarge, {}) })
    }
  );
};
const { loadRemote } = index_cjs;
const { initPromise } = supos_mf_2_ce_mf_1_ThemeManagement__mf_v__runtimeInit__mf_v__;
const res = initPromise.then((_) => loadRemote("@supos_host/utils"));
const exportModule = await initPromise.then((_) => res);
var supos_mf_2_ce_mf_1_ThemeManagement__loadRemote___mf_0_supos_host_mf_1_utils__loadRemote__ = exportModule;
const baseUrl = "/inter-api/supos/theme";
const api = new supos_mf_2_ce_mf_1_ThemeManagement__loadRemote___mf_0_supos_host_mf_1_utils__loadRemote__.ApiWrapper(baseUrl);
const generalConfigSave = async (params) => api.uploads("/general-config/save", params, { method: "post" });
const loginConfigSave = async (params) => api.uploads("/login-page-config/save", params, { method: "post" });
const resetAllThemeConfig = async (type) => api.post(`/config/reset?type=${type}`);
const getAllThemeConfig = async (params) => api.get("/getConfig", { params });
const commonConfigForm = "_commonConfigForm_1uhv8_1";
const title$2 = "_title_1uhv8_4";
const imageSize = "_imageSize_1uhv8_8";
const styles$2 = {
  commonConfigForm,
  title: title$2,
  imageSize
};
const ButtonPermission = {
  "ThemeManagement.reset": `${I18N_NAME}.reset`,
  "ThemeManagement.save": `${I18N_NAME}.save`
};
const DEFAULT_IMAGE_PATH = new URL("data:image/svg+xml,%3csvg%20width='200'%20height='200'%20viewBox='0%200%20200%20200'%20fill='none'%20xmlns='http://www.w3.org/2000/svg'%3e%3crect%20width='200'%20height='200'%20rx='100'%20fill='%23B2ED1D'/%3e%3cpath%20d='M53.5535%20147.323V52.6771L67.5751%2038.6555H132.425L146.447%2052.6771V147.323L132.425%20161.344H67.5751L53.5535%20147.323ZM69.3278%2052.6771V147.323H130.672V52.6771H69.3278Z'%20fill='%23050B14'/%3e%3c/svg%3e", import.meta.url).href;
const DEFAULT_IMAGE_PATH_ICO = new URL("data:image/svg+xml,%3csvg%20width='100'%20height='16'%20viewBox='0%200%20100%2016'%20fill='none'%20xmlns='http://www.w3.org/2000/svg'%3e%3cpath%20d='M4.85876%2015.9096V1.89831H0V0.0903957H11.7514V1.89831H6.89265V15.9096H4.85876Z'%20fill='%23050B14'/%3e%3cpath%20d='M12.5327%2016V14.1921L15.3575%2014.0791V1.9209L12.5327%201.80791V0L16.3745%200.180791L20.2163%200V1.80791L17.3914%201.9209V14.0791L20.2163%2014.1921V16L16.3745%2015.8192L12.5327%2016Z'%20fill='%23050B14'/%3e%3cpath%20d='M21.9041%2015.9096V0.0903957H32.7516V1.89831H23.938V6.87006H31.6216V8.67797H23.938V14.1017H32.9776V15.9096H21.9041Z'%20fill='%23050B14'/%3e%3cpath%20d='M36.3692%208.67797H44.2788V1.89831H36.3692V8.67797ZM46.3127%201.89831V8.67797L44.7985%2010.1921L47.5556%2015.9096H45.3635L42.8098%2010.4859H36.3692V15.9096H34.3353V0.0903957H44.5048L46.3127%201.89831Z'%20fill='%23050B14'/%3e%3cpath%20d='M53.0959%2014.1017V1.89831L54.9038%200.0903957H63.2654L65.0733%201.89831V14.1017L63.2654%2015.9096H54.9038L53.0959%2014.1017ZM55.1298%201.89831V14.1017H63.0394V1.89831H55.1298Z'%20fill='%2373B200'/%3e%3crect%20x='71.2627'%20y='1.48438'%20width='28.1891'%20height='13.0315'%20rx='1.03151'%20fill='%23050B14'/%3e%3cpath%20d='M74.9144%2011V4.50149H79.3706V5.24418H75.75V7.28657H78.9064V8.02925H75.75V10.2573H79.4634V11H74.9144ZM84.6629%204.50149V11H80.8102L79.9747%2010.1645V6.63671L80.8102%205.80119H83.8274V4.50149H84.6629ZM80.8102%2010.2573H83.8274V6.54388H80.8102V10.2573ZM85.778%2012.2997V11.557H89.213V10.2573H86.2886L85.4531%209.42179V6.63671L86.3815%205.80119H90.0485V11.427L89.1758%2012.2997H85.778ZM86.2886%206.54388V9.51463H89.213V6.54388H86.2886ZM90.8409%2010.1645V6.63671L91.6764%205.80119H95.297V8.6791H91.6764V10.2573H95.1113V11H91.6764L90.8409%2010.1645ZM91.6764%208.02925L94.4986%207.93642V6.54388H91.6764V8.02925Z'%20fill='white'/%3e%3c/svg%3e", import.meta.url).href;
const iconDefaultList = [
  {
    uid: "-1",
    name: "logo-ico.svg",
    url: DEFAULT_IMAGE_PATH
  }
];
const iconNavList = [
  {
    uid: "-1",
    name: "logo.svg",
    url: DEFAULT_IMAGE_PATH_ICO
  }
];
const Module$1 = ({ themeConfig }) => {
  const [form] = supos_mf_2_ce_mf_1_ThemeManagement__loadShare__antd__loadShare__.Form.useForm();
  const { message } = supos_mf_2_ce_mf_1_ThemeManagement__loadShare__antd__loadShare__.App.useApp();
  const formatMessage = supos_mf_2_ce_mf_1_ThemeManagement__loadRemote___mf_0_supos_host_mf_1_hooks__loadRemote__.useTranslate(I18N_NAME);
  const { appTitle } = supos_mf_2_ce_mf_1_ThemeManagement__loadRemote___mf_0_supos_host_mf_1_baseStore__loadRemote__.useBaseStore((state) => state.systemInfo);
  const lang = supos_mf_2_ce_mf_1_ThemeManagement__loadRemote___mf_0_supos_host_mf_1_i18nStore__loadRemote__.useI18nStore((state) => state.lang);
  const [defaultBrowserTitle, setDefaultBrowserTitle] = supos_mf_2_ce_mf_1_ThemeManagement__loadShare__react__loadShare__.useState();
  const [browserIconList, setBrowserIconList] = supos_mf_2_ce_mf_1_ThemeManagement__loadShare__react__loadShare__.useState();
  const [navLogoList, setNavLogoList] = supos_mf_2_ce_mf_1_ThemeManagement__loadShare__react__loadShare__.useState();
  const rebuildList = (path) => {
    const timestamp = (/* @__PURE__ */ new Date()).getTime();
    return path ? [
      {
        uid: "-1",
        name: "img.png",
        url: `${location.origin}${path}?t=${timestamp}`
      }
    ] : void 0;
  };
  const addToFileList = (list, name, dataList, cb) => {
    var _a;
    if (list == null ? void 0 : list.length) {
      if ((_a = list[0]) == null ? void 0 : _a.file) {
        dataList == null ? void 0 : dataList.push({
          name,
          value: list[0].file,
          fileName: list[0].file.fileName
        });
      }
    } else {
      cb();
    }
  };
  const save = async () => {
    const values = await form.validateFields();
    const dataList = [
      {
        name: "browseTitle",
        value: values.browserTitle
      }
    ];
    let resetIcon = 0;
    addToFileList(browserIconList, "browseIcon", dataList, () => resetIcon += 1);
    addToFileList(navLogoList, "navigationIcon", dataList, () => resetIcon += 2);
    if (resetIcon) {
      dataList.push({
        name: "resetIcon",
        value: resetIcon
      });
    }
    const saveRes = await generalConfigSave(dataList);
    if (saveRes) {
      message.success(formatMessage("saveSuccess"));
    }
  };
  const reset = async () => {
    const res2 = await resetAllThemeConfig(0);
    if (res2) {
      message.success(formatMessage("resetSuccess"));
      form.setFieldValue("browserTitle", defaultBrowserTitle);
      setBrowserIconList(iconDefaultList);
      setNavLogoList(iconNavList);
    }
  };
  const getConfig = async (themeConfig2, init, title2) => {
    const { browseTitle, browseIcon, navigationIcon } = themeConfig2 || {};
    {
      form.setFieldValue("browserTitle", browseTitle || title2);
      setBrowserIconList(rebuildList(browseIcon) || iconDefaultList);
      setNavLogoList(rebuildList(navigationIcon) || iconNavList);
    }
  };
  supos_mf_2_ce_mf_1_ThemeManagement__loadShare__react__loadShare__.useEffect(() => {
    const _browserTitle = `${appTitle}`;
    setDefaultBrowserTitle(_browserTitle);
    getConfig(themeConfig, true, _browserTitle);
  }, [appTitle, themeConfig, lang]);
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(
    supos_mf_2_ce_mf_1_ThemeManagement__loadShare__antd__loadShare__.Form,
    {
      className: styles$2.commonConfigForm,
      name: "commonConfigForm",
      form,
      colon: false,
      labelCol: { span: 8 },
      wrapperCol: { span: 16 },
      labelAlign: "left",
      labelWrap: true,
      children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs(supos_mf_2_ce_mf_1_ThemeManagement__loadShare__antd__loadShare__.Flex, { align: "center", justify: "space-between", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: styles$2.title, children: formatMessage("commonConfig") }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(supos_mf_2_ce_mf_1_ThemeManagement__loadShare__antd__loadShare__.Flex, { align: "center", gap: 10, children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_ThemeManagement__loadRemote___mf_0_supos_host_mf_1_components__loadRemote__.AuthButton, { auth: ButtonPermission["ThemeManagement.save"], type: "primary", onClick: save, children: formatMessage("save") }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_ThemeManagement__loadRemote___mf_0_supos_host_mf_1_components__loadRemote__.AuthButton, { auth: ButtonPermission["ThemeManagement.reset"], onClick: reset, children: formatMessage("reset") })
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_ThemeManagement__loadShare__antd__loadShare__.Divider, { style: { borderColor: "#c6c6c6" } }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_ThemeManagement__loadShare__antd__loadShare__.Form.Item, { name: "browserTitle", label: formatMessage("browserTitle"), children: /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_ThemeManagement__loadShare__antd__loadShare__.Input, {}) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_ThemeManagement__loadShare__antd__loadShare__.Form.Item, { name: "browserIcon", label: formatMessage("browserIcon"), children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            Module$2,
            {
              maxCount: 1,
              fileList: browserIconList,
              fileChange: (file) => {
                setBrowserIconList(file);
              }
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: styles$2.imageSize, children: formatMessage("imageSize", { size: "32*32" }) })
        ] }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_ThemeManagement__loadShare__antd__loadShare__.Form.Item, { name: "navigationLogo", label: formatMessage("navigationLogo"), children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            Module$2,
            {
              maxCount: 1,
              fileList: navLogoList,
              fileChange: (file) => {
                setNavLogoList(file);
              }
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: styles$2.imageSize, children: formatMessage("imageSize", { size: "50*20" }) })
        ] }) })
      ]
    }
  );
};
const lightThemeImage = "data:image/svg+xml,%3csvg%20width='216'%20height='126'%20viewBox='0%200%20216%20126'%20fill='none'%20xmlns='http://www.w3.org/2000/svg'%3e%3crect%20x='1.01172'%20y='0.5'%20width='214'%20height='124.578'%20rx='2.5'%20fill='white'/%3e%3crect%20x='1.01172'%20y='0.5'%20width='214'%20height='124.578'%20rx='2.5'%20stroke='%23C6C6C6'/%3e%3crect%20x='25.5117'%20y='16'%20width='164.994'%20height='23.3945'%20fill='%23F4F4F4'/%3e%3cmask%20id='path-3-inside-1_8835_70494'%20fill='white'%3e%3cpath%20d='M25.5117%2039.3945H190.506V62.7891H25.5117V39.3945Z'/%3e%3c/mask%3e%3cpath%20d='M25.5117%2039.3945H190.506V62.7891H25.5117V39.3945Z'%20fill='white'/%3e%3cpath%20d='M190.506%2062.7891V61.7891H25.5117V62.7891V63.7891H190.506V62.7891Z'%20fill='%23C6C6C6'%20mask='url(%23path-3-inside-1_8835_70494)'/%3e%3cmask%20id='path-5-inside-2_8835_70494'%20fill='white'%3e%3cpath%20d='M25.5117%2062.7891H190.506V86.1836H25.5117V62.7891Z'/%3e%3c/mask%3e%3cpath%20d='M25.5117%2062.7891H190.506V86.1836H25.5117V62.7891Z'%20fill='white'/%3e%3cpath%20d='M190.506%2086.1836V85.1836H25.5117V86.1836V87.1836H190.506V86.1836Z'%20fill='%23C6C6C6'%20mask='url(%23path-5-inside-2_8835_70494)'/%3e%3cmask%20id='path-7-inside-3_8835_70494'%20fill='white'%3e%3cpath%20d='M25.5117%2086.1836H190.506V109.578H25.5117V86.1836Z'/%3e%3c/mask%3e%3cpath%20d='M25.5117%2086.1836H190.506V109.578H25.5117V86.1836Z'%20fill='white'/%3e%3cpath%20d='M190.506%20109.578V108.578H25.5117V109.578V110.578H190.506V109.578Z'%20fill='%23C6C6C6'%20mask='url(%23path-7-inside-3_8835_70494)'/%3e%3c/svg%3e";
const darkThemeImage = "data:image/svg+xml,%3csvg%20width='216'%20height='126'%20viewBox='0%200%20216%20126'%20fill='none'%20xmlns='http://www.w3.org/2000/svg'%3e%3crect%20x='1.01172'%20y='0.789062'%20width='214'%20height='124'%20rx='2.5'%20fill='%23161616'/%3e%3crect%20x='1.01172'%20y='0.789062'%20width='214'%20height='124'%20rx='2.5'%20stroke='%23C6C6C6'/%3e%3crect%20x='25.6367'%20y='16'%20width='164.994'%20height='23.3945'%20fill='%23393939'/%3e%3cmask%20id='path-3-inside-1_8835_70502'%20fill='white'%3e%3cpath%20d='M25.6367%2039.3945H190.631V62.7891H25.6367V39.3945Z'/%3e%3c/mask%3e%3cpath%20d='M25.6367%2039.3945H190.631V62.7891H25.6367V39.3945Z'%20fill='%23161616'/%3e%3cpath%20d='M190.631%2062.7891V61.7891H25.6367V62.7891V63.7891H190.631V62.7891Z'%20fill='%23C6C6C6'%20mask='url(%23path-3-inside-1_8835_70502)'/%3e%3cmask%20id='path-5-inside-2_8835_70502'%20fill='white'%3e%3cpath%20d='M25.6367%2062.7891H190.631V86.1836H25.6367V62.7891Z'/%3e%3c/mask%3e%3cpath%20d='M25.6367%2062.7891H190.631V86.1836H25.6367V62.7891Z'%20fill='%23161616'/%3e%3cpath%20d='M190.631%2086.1836V85.1836H25.6367V86.1836V87.1836H190.631V86.1836Z'%20fill='%23C6C6C6'%20mask='url(%23path-5-inside-2_8835_70502)'/%3e%3cmask%20id='path-7-inside-3_8835_70502'%20fill='white'%3e%3cpath%20d='M25.6367%2086.1836H190.631V109.578H25.6367V86.1836Z'/%3e%3c/mask%3e%3cpath%20d='M25.6367%2086.1836H190.631V109.578H25.6367V86.1836Z'%20fill='%23161616'/%3e%3cpath%20d='M190.631%20109.578V108.578H25.6367V109.578V110.578H190.631V109.578Z'%20fill='%23C6C6C6'%20mask='url(%23path-7-inside-3_8835_70502)'/%3e%3c/svg%3e";
const loginConfigForm = "_loginConfigForm_139wf_1";
const title$1 = "_title_139wf_4";
const themeImg = "_themeImg_139wf_8";
const selectTheme = "_selectTheme_139wf_13";
const styles$1 = {
  loginConfigForm,
  title: title$1,
  themeImg,
  selectTheme
};
const LOGO_LIGHT_PATH = new URL("data:image/svg+xml,%3csvg%20width='100'%20height='16'%20viewBox='0%200%20100%2016'%20fill='none'%20xmlns='http://www.w3.org/2000/svg'%3e%3cpath%20d='M4.85876%2015.9096V1.89831H0V0.0903957H11.7514V1.89831H6.89265V15.9096H4.85876Z'%20fill='%23050B14'/%3e%3cpath%20d='M12.5327%2016V14.1921L15.3575%2014.0791V1.9209L12.5327%201.80791V0L16.3745%200.180791L20.2163%200V1.80791L17.3914%201.9209V14.0791L20.2163%2014.1921V16L16.3745%2015.8192L12.5327%2016Z'%20fill='%23050B14'/%3e%3cpath%20d='M21.9041%2015.9096V0.0903957H32.7516V1.89831H23.938V6.87006H31.6216V8.67797H23.938V14.1017H32.9776V15.9096H21.9041Z'%20fill='%23050B14'/%3e%3cpath%20d='M36.3692%208.67797H44.2788V1.89831H36.3692V8.67797ZM46.3127%201.89831V8.67797L44.7985%2010.1921L47.5556%2015.9096H45.3635L42.8098%2010.4859H36.3692V15.9096H34.3353V0.0903957H44.5048L46.3127%201.89831Z'%20fill='%23050B14'/%3e%3cpath%20d='M53.0959%2014.1017V1.89831L54.9038%200.0903957H63.2654L65.0733%201.89831V14.1017L63.2654%2015.9096H54.9038L53.0959%2014.1017ZM55.1298%201.89831V14.1017H63.0394V1.89831H55.1298Z'%20fill='%2373B200'/%3e%3crect%20x='71.2627'%20y='1.48438'%20width='28.1891'%20height='13.0315'%20rx='1.03151'%20fill='%23050B14'/%3e%3cpath%20d='M74.9144%2011V4.50149H79.3706V5.24418H75.75V7.28657H78.9064V8.02925H75.75V10.2573H79.4634V11H74.9144ZM84.6629%204.50149V11H80.8102L79.9747%2010.1645V6.63671L80.8102%205.80119H83.8274V4.50149H84.6629ZM80.8102%2010.2573H83.8274V6.54388H80.8102V10.2573ZM85.778%2012.2997V11.557H89.213V10.2573H86.2886L85.4531%209.42179V6.63671L86.3815%205.80119H90.0485V11.427L89.1758%2012.2997H85.778ZM86.2886%206.54388V9.51463H89.213V6.54388H86.2886ZM90.8409%2010.1645V6.63671L91.6764%205.80119H95.297V8.6791H91.6764V10.2573H95.1113V11H91.6764L90.8409%2010.1645ZM91.6764%208.02925L94.4986%207.93642V6.54388H91.6764V8.02925Z'%20fill='white'/%3e%3c/svg%3e", import.meta.url).href;
const LOGO_DARK_PATH = new URL("data:image/svg+xml,%3csvg%20width='100'%20height='16'%20viewBox='0%200%20100%2016'%20fill='none'%20xmlns='http://www.w3.org/2000/svg'%3e%3cpath%20d='M4.85876%2015.9096V1.89831H0V0.0903957H11.7514V1.89831H6.89265V15.9096H4.85876Z'%20fill='white'/%3e%3cpath%20d='M12.5327%2016V14.1921L15.3575%2014.0791V1.9209L12.5327%201.80791V0L16.3745%200.180791L20.2163%200V1.80791L17.3914%201.9209V14.0791L20.2163%2014.1921V16L16.3745%2015.8192L12.5327%2016Z'%20fill='white'/%3e%3cpath%20d='M21.9041%2015.9096V0.0903957H32.7516V1.89831H23.938V6.87006H31.6216V8.67797H23.938V14.1017H32.9776V15.9096H21.9041Z'%20fill='white'/%3e%3cpath%20d='M36.3692%208.67797H44.2788V1.89831H36.3692V8.67797ZM46.3127%201.89831V8.67797L44.7985%2010.1921L47.5556%2015.9096H45.3635L42.8098%2010.4859H36.3692V15.9096H34.3353V0.0903957H44.5048L46.3127%201.89831Z'%20fill='white'/%3e%3cpath%20d='M53.0959%2014.1017V1.89831L54.9038%200.0903957H63.2654L65.0733%201.89831V14.1017L63.2654%2015.9096H54.9038L53.0959%2014.1017ZM55.1298%201.89831V14.1017H63.0394V1.89831H55.1298Z'%20fill='%2373B200'/%3e%3crect%20x='71.2627'%20y='1.48438'%20width='28.1891'%20height='13.0315'%20rx='1.03151'%20fill='white'/%3e%3cpath%20d='M74.9144%2011V4.50149H79.3706V5.24418H75.75V7.28657H78.9064V8.02925H75.75V10.2573H79.4634V11H74.9144ZM84.6629%204.50149V11H80.8102L79.9747%2010.1645V6.63671L80.8102%205.80119H83.8274V4.50149H84.6629ZM80.8102%2010.2573H83.8274V6.54388H80.8102V10.2573ZM85.778%2012.2997V11.557H89.213V10.2573H86.2886L85.4531%209.42179V6.63671L86.3815%205.80119H90.0485V11.427L89.1758%2012.2997H85.778ZM86.2886%206.54388V9.51463H89.213V6.54388H86.2886ZM90.8409%2010.1645V6.63671L91.6764%205.80119H95.297V8.6791H91.6764V10.2573H95.1113V11H91.6764L90.8409%2010.1645ZM91.6764%208.02925L94.4986%207.93642V6.54388H91.6764V8.02925Z'%20fill='%23050B14'/%3e%3c/svg%3e", import.meta.url).href;
const BACKGROUND_IMAGE_PATH = new URL("/plugin/ThemeManagement/assets/login-background-C4GUgBfm.png", import.meta.url).href;
const logoDefaultList = [
  {
    uid: "-1",
    name: "logo.svg",
    url: LOGO_LIGHT_PATH
  }
];
const backgroundDefaultList = [
  {
    uid: "-1",
    name: "login-background.png",
    url: BACKGROUND_IMAGE_PATH
  }
];
const sloganLightZhDefaultList = [
  {
    uid: "-1",
    name: "slogan-light-zh.png"
    // url: SLOGAN_LIGHT_ZH_IMAGE_PATH,
  }
];
const sloganLightEnDefaultList = [
  {
    uid: "-1",
    name: "slogan-light-en.png"
    // url: SLOGAN_LIGHT_EN_IMAGE_PATH,
  }
];
const Module = ({ themeConfig, getConfig }) => {
  const [form] = supos_mf_2_ce_mf_1_ThemeManagement__loadShare__antd__loadShare__.Form.useForm();
  const { message } = supos_mf_2_ce_mf_1_ThemeManagement__loadShare__antd__loadShare__.App.useApp();
  const formatMessage = supos_mf_2_ce_mf_1_ThemeManagement__loadRemote___mf_0_supos_host_mf_1_hooks__loadRemote__.useTranslate(I18N_NAME);
  const lang = supos_mf_2_ce_mf_1_ThemeManagement__loadRemote___mf_0_supos_host_mf_1_i18nStore__loadRemote__.useI18nStore((state) => state.lang);
  const [logoList, setLogoList] = supos_mf_2_ce_mf_1_ThemeManagement__loadShare__react__loadShare__.useState();
  const [backgroundList, setBackgroundList] = supos_mf_2_ce_mf_1_ThemeManagement__loadShare__react__loadShare__.useState();
  const [sloganList, setSloganList] = supos_mf_2_ce_mf_1_ThemeManagement__loadShare__react__loadShare__.useState();
  const defaultConfig = supos_mf_2_ce_mf_1_ThemeManagement__loadShare__react__loadShare__.useMemo(
    () => ({
      loginPageType: 0,
      brightLogoIcon: LOGO_LIGHT_PATH,
      brightBackgroundIcon: BACKGROUND_IMAGE_PATH,
      // brightSloganIcon: lang === 'zh-CN' ? SLOGAN_LIGHT_ZH_IMAGE_PATH : SLOGAN_LIGHT_EN_IMAGE_PATH,
      darkLogoIcon: LOGO_DARK_PATH,
      darkBackgroundIcon: BACKGROUND_IMAGE_PATH
      // darkSloganIcon: lang === 'zh-CN' ? SLOGAN_DARK_ZH_IMAGE_PATH : SLOGAN_DARK_EN_IMAGE_PATH,
    }),
    [lang]
  );
  const [allConfig, setAllConfig] = supos_mf_2_ce_mf_1_ThemeManagement__loadShare__react__loadShare__.useState({ ...defaultConfig, ...themeConfig });
  const [init, setInit] = supos_mf_2_ce_mf_1_ThemeManagement__loadShare__react__loadShare__.useState(true);
  const theme = supos_mf_2_ce_mf_1_ThemeManagement__loadShare__antd__loadShare__.Form.useWatch("theme", form);
  const saveStatusRef = supos_mf_2_ce_mf_1_ThemeManagement__loadShare__react__loadShare__.useRef(false);
  const removeObjNoValKey = (obj) => {
    if (!obj) return {};
    Object.keys(obj).forEach((key) => {
      if (!obj[key]) delete obj[key];
    });
    return obj;
  };
  const rebuildList = (path) => {
    return path ? [
      {
        uid: "-1",
        name: "img.png",
        url: `${path.includes("http") ? "" : location.origin}${path}`
      }
    ] : void 0;
  };
  const addToFileList = (list, name, dataList, cb) => {
    var _a;
    if (list == null ? void 0 : list.length) {
      if ((_a = list[0]) == null ? void 0 : _a.file) {
        dataList == null ? void 0 : dataList.push({
          name,
          value: list[0].file,
          fileName: list[0].file.fileName
        });
      }
    } else {
      cb();
    }
  };
  const save = async () => {
    saveStatusRef.current = true;
    const values = await form.validateFields();
    const { theme: theme2 } = values;
    const dataList = [
      {
        name: "loginPageType",
        value: theme2
      }
    ];
    let resetIcon = 0;
    addToFileList(logoList, theme2 ? "darkLogoIcon" : "brightLogoIcon", dataList, () => {
      resetIcon += 1;
    });
    addToFileList(backgroundList, theme2 ? "darkBackgroundIcon" : "brightBackgroundIcon", dataList, () => {
      resetIcon += 2;
    });
    addToFileList(sloganList, theme2 ? "darkSloganIcon" : "brightSloganIcon", dataList, () => {
      resetIcon += 4;
    });
    if (resetIcon) {
      dataList.push({
        name: theme2 ? "resetDarkIcon" : "resetBrightIcon",
        value: resetIcon
      });
    }
    const saveRes = await loginConfigSave(dataList);
    if (saveRes) {
      message.success(formatMessage("saveSuccess"));
      getConfig();
    }
  };
  const reset = async () => {
    const res2 = await resetAllThemeConfig(1);
    if (res2) {
      message.success(formatMessage("resetSuccess"));
      form.setFieldValue("theme", 0);
      setSloganList(lang === "zh-CN" ? sloganLightZhDefaultList : sloganLightEnDefaultList);
      setLogoList(logoDefaultList);
      setBackgroundList(backgroundDefaultList);
      getConfig();
    }
  };
  const handleConfig = async (config, init2, requestConfig) => {
    const {
      loginPageType,
      brightLogoIcon,
      brightBackgroundIcon,
      brightSloganIcon,
      darkLogoIcon,
      darkBackgroundIcon,
      darkSloganIcon
    } = config || {};
    if (init2) {
      form.setFieldValue("theme", loginPageType);
      const logo = rebuildList(loginPageType ? darkLogoIcon : brightLogoIcon);
      const background = rebuildList(loginPageType ? darkBackgroundIcon : brightBackgroundIcon);
      const sloganIcon = rebuildList(loginPageType ? darkSloganIcon : brightSloganIcon);
      setLogoList(logo);
      setBackgroundList(background);
      setSloganList(sloganIcon);
    } else {
      if (saveStatusRef.current) {
        saveStatusRef.current = false;
      } else {
        const sloganIcon = rebuildList(theme ? darkSloganIcon : brightSloganIcon);
        setSloganList(sloganIcon);
      }
    }
    if (requestConfig) setInit(false);
  };
  const handleThemeChange = (e) => {
    const { brightLogoIcon, brightBackgroundIcon, brightSloganIcon, darkLogoIcon, darkBackgroundIcon, darkSloganIcon } = allConfig;
    const loginPageType = e.target.value;
    const logo = rebuildList(loginPageType ? darkLogoIcon : brightLogoIcon);
    const background = rebuildList(loginPageType ? darkBackgroundIcon : brightBackgroundIcon);
    const sloganIcon = rebuildList(loginPageType ? darkSloganIcon : brightSloganIcon);
    setLogoList(logo);
    setBackgroundList(background);
    setSloganList(sloganIcon);
  };
  supos_mf_2_ce_mf_1_ThemeManagement__loadShare__react__loadShare__.useEffect(() => {
    const _allConfig = { ...defaultConfig, ...removeObjNoValKey(themeConfig) };
    console.log(_allConfig);
    setAllConfig(_allConfig);
    handleConfig(_allConfig, init, themeConfig);
  }, [defaultConfig, themeConfig, init]);
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(
    supos_mf_2_ce_mf_1_ThemeManagement__loadShare__antd__loadShare__.Form,
    {
      className: styles$1.loginConfigForm,
      name: "loginConfigForm",
      form,
      colon: false,
      labelCol: { span: 8 },
      wrapperCol: { span: 16 },
      labelAlign: "left",
      labelWrap: true,
      children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs(supos_mf_2_ce_mf_1_ThemeManagement__loadShare__antd__loadShare__.Flex, { align: "center", justify: "space-between", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: styles$1.title, children: formatMessage("loginConfig") }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(supos_mf_2_ce_mf_1_ThemeManagement__loadShare__antd__loadShare__.Flex, { align: "center", gap: 10, children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_ThemeManagement__loadShare__antd__loadShare__.Button, { type: "primary", onClick: save, children: formatMessage("save") }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_ThemeManagement__loadShare__antd__loadShare__.Button, { onClick: reset, children: formatMessage("reset") })
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_ThemeManagement__loadShare__antd__loadShare__.Divider, { style: { borderColor: "#c6c6c6" } }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_ThemeManagement__loadShare__antd__loadShare__.Form.Item, { name: "theme", label: formatMessage("theme"), children: /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_ThemeManagement__loadShare__antd__loadShare__.Radio.Group, { onChange: handleThemeChange, children: /* @__PURE__ */ jsxRuntimeExports.jsxs(supos_mf_2_ce_mf_1_ThemeManagement__loadShare__antd__loadShare__.Flex, { gap: 10, children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs(supos_mf_2_ce_mf_1_ThemeManagement__loadShare__antd__loadShare__.Flex, { vertical: true, align: "center", gap: 10, children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("img", { className: `${styles$1.themeImg} ${theme === 0 ? styles$1.selectTheme : ""}`, src: lightThemeImage }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_ThemeManagement__loadShare__antd__loadShare__.Radio, { value: 0, children: formatMessage("lightTheme") })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(supos_mf_2_ce_mf_1_ThemeManagement__loadShare__antd__loadShare__.Flex, { vertical: true, align: "center", gap: 10, children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("img", { className: `${styles$1.themeImg} ${theme === 1 ? styles$1.selectTheme : ""}`, src: darkThemeImage }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_ThemeManagement__loadShare__antd__loadShare__.Radio, { value: 1, children: formatMessage("darkTheme") })
          ] })
        ] }) }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_ThemeManagement__loadShare__antd__loadShare__.Form.Item, { name: "logo", label: formatMessage("logo"), children: /* @__PURE__ */ jsxRuntimeExports.jsx(
          Module$2,
          {
            maxCount: 1,
            fileList: logoList,
            fileChange: (file) => {
              setLogoList(file);
            }
          }
        ) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_ThemeManagement__loadShare__antd__loadShare__.Form.Item, { name: "background", label: formatMessage("background"), children: /* @__PURE__ */ jsxRuntimeExports.jsx(
          Module$2,
          {
            maxCount: 1,
            fileList: backgroundList,
            fileChange: (file) => {
              setBackgroundList(file);
            },
            style: { width: "450px" }
          }
        ) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_ThemeManagement__loadShare__antd__loadShare__.Form.Item, { name: "slogan", label: formatMessage("slogan"), children: /* @__PURE__ */ jsxRuntimeExports.jsx(
          Module$2,
          {
            maxCount: 1,
            fileList: sloganList,
            fileChange: (file) => {
              setSloganList(file);
            }
          }
        ) })
      ]
    }
  );
};
const themeConfigWrap = "_themeConfigWrap_cewkv_1";
const titleBox = "_titleBox_cewkv_1";
const title = "_title_cewkv_1";
const styles = {
  themeConfigWrap,
  titleBox,
  title
};
const CodeManagement = () => {
  const formatMessage = supos_mf_2_ce_mf_1_ThemeManagement__loadRemote___mf_0_supos_host_mf_1_hooks__loadRemote__.useTranslate(I18N_NAME);
  const [themeConfig, setThemeConfig] = supos_mf_2_ce_mf_1_ThemeManagement__loadShare__react__loadShare__.useState();
  const getConfig = async () => {
    const res2 = await getAllThemeConfig();
    res2.loginPageType = res2.loginPageType || 0;
    setThemeConfig(res2);
  };
  supos_mf_2_ce_mf_1_ThemeManagement__loadShare__react__loadShare__.useEffect(() => {
    getConfig();
  }, []);
  return /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_ThemeManagement__loadRemote___mf_0_supos_host_mf_1_components__loadRemote__.ComLayout, { loading: false, children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
    supos_mf_2_ce_mf_1_ThemeManagement__loadRemote___mf_0_supos_host_mf_1_components__loadRemote__.ComContent,
    {
      className: styles.themeConfigWrap,
      title: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: styles.titleBox, children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_ThemeManagement__loadShare___mf_0_carbon_mf_1_icons_mf_2_react__loadShare__.PaintBrush, {}),
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: styles.title, children: formatMessage("themeConfig") })
      ] }),
      mustHasBack: false,
      style: {
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        padding: "30px 0"
      },
      children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Module$1, { themeConfig }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Module, { themeConfig, getConfig })
      ]
    }
  ) });
};
const App = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: CodeManagement
}, Symbol.toStringTag, { value: "Module" }));
export {
  App as A,
  CodeManagement as C,
  jsxRuntimeExports as j
};
