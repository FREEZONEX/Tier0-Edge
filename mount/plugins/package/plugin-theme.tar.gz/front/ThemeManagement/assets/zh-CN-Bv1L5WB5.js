const themeConfig = "主题配置";
const commonConfig = "通用配置";
const browserTitle = "浏览器标题";
const browserIcon = "浏览器图标";
const navigationLogo = "导航栏logo";
const loginConfig = "登录页配置";
const theme = "主题";
const lightTheme = "亮色主题";
const darkTheme = "暗色主题";
const logo = "LOGO";
const background = "背景";
const slogan = "标语";
const save = "保存";
const reset = "重置";
const imgFormatSupport = "图片格式支持：{format}";
const saveSuccess = "保存成功";
const resetSuccess = "重置成功";
const imageSize = "图片尺寸大小：{size}";
const zhCN = {
  themeConfig,
  commonConfig,
  browserTitle,
  browserIcon,
  navigationLogo,
  loginConfig,
  theme,
  lightTheme,
  darkTheme,
  logo,
  background,
  slogan,
  save,
  reset,
  imgFormatSupport,
  saveSuccess,
  resetSuccess,
  imageSize
};
export {
  background,
  browserIcon,
  browserTitle,
  commonConfig,
  darkTheme,
  zhCN as default,
  imageSize,
  imgFormatSupport,
  lightTheme,
  loginConfig,
  logo,
  navigationLogo,
  reset,
  resetSuccess,
  save,
  saveSuccess,
  slogan,
  theme,
  themeConfig
};
