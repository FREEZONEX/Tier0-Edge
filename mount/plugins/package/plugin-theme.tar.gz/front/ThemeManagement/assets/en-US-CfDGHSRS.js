const themeConfig = "Appearance Settings";
const commonConfig = "General Settings";
const browserTitle = "Browser Tab Title";
const browserIcon = "Browser Favicon";
const navigationLogo = "Navigation Bar Logo";
const loginConfig = "Login Settings";
const theme = "Theme";
const lightTheme = "Light";
const darkTheme = "Dark";
const logo = "LOGO";
const background = "Background Image";
const slogan = "Slogan";
const save = "Save";
const reset = "Restore Defaults";
const imgFormatSupport = "Image format support: {format}";
const saveSuccess = "Successfully saved";
const resetSuccess = "Reset successful";
const imageSize = "Image size：{size}";
const enUS = {
  themeConfig,
  commonConfig,
  browserTitle,
  browserIcon,
  navigationLogo,
  loginConfig,
  theme,
  lightTheme,
  darkTheme,
  logo,
  background,
  slogan,
  save,
  reset,
  imgFormatSupport,
  saveSuccess,
  resetSuccess,
  imageSize
};
export {
  background,
  browserIcon,
  browserTitle,
  commonConfig,
  darkTheme,
  enUS as default,
  imageSize,
  imgFormatSupport,
  lightTheme,
  loginConfig,
  logo,
  navigationLogo,
  reset,
  resetSuccess,
  save,
  saveSuccess,
  slogan,
  theme,
  themeConfig
};
